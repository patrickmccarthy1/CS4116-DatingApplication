<?php
$servername = "sql201.epizy.com";
$username = "epiz_31350285";
$password = "OjpWMi5f1c";
$dbname = "epiz_31350285_spark";

//Connect to database
$conn = new mysqli($servername, $username, $password, $dbname);

//Check the connection
if ($conn->connect_error) {

  die("Connection Failed: " . $conn->connect_error);
} else {

  echo "Connected Successfully";
}
